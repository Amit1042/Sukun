﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImportListFromCSV
{
    class CsvReader
    {
        private System.IO.StreamReader sr;

        public CsvReader(System.IO.StreamReader sr)
        {
            // TODO: Complete member initialization
            this.sr = sr;
        }

        internal object GetRecords<T1>()
        {
            throw new NotImplementedException();
        }
    }
}
