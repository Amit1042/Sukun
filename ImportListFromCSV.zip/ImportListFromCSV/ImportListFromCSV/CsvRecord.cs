﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportListFromCSV
{
    class CsvRecord
    {

        public string person_id { get; set; }
        public string Prefix { get; set; }
        public float First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Generational { get; set; }
        public string Initials { get; set; }
        public bool Common_Name { get; set; }
        public string Email { get; set; }
        public string Home_Phone { get; set; }
        public string Cell_Phone { get; set; }
    }
}
