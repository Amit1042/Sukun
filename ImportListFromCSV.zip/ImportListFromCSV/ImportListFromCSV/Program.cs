﻿using System;
using System.IO;
using System.Configuration;
using System.Collections.Generic;
using System.Reflection;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Utilities;
using System.Collections.Specialized;
using System.Data;





namespace ImportListFromCSV
{
    class Program
    {
        const string filePath = @"C:\Marketing20190530.csv";
        static DataTable dtCsv = new DataTable();
        static void Main()
        {
            getCSV();
            try
            {
                //Get site URL and credentials values from config
                Uri siteUri = new Uri(ConfigurationManager.AppSettings["SiteUrl"].ToString());
                var accountName = ConfigurationManager.AppSettings["AccountName"];
                char[] pwdChars = ConfigurationManager.AppSettings["AccountPwd"].ToCharArray();
                //Convert password to secure string
                System.Security.SecureString accountPwd = new System.Security.SecureString();
                for (int i = 0; i < pwdChars.Length; i++)
                {
                    accountPwd.AppendChar(pwdChars[i]);
                }
                //Connect to SharePoint Online
                using (var clientContext = new ClientContext(siteUri.ToString())
                {
                    Credentials = new SharePointOnlineCredentials(accountName, accountPwd)
                })
                {
                    if (clientContext != null)
                    {
                        //Map records from CSV file to C# list
                        //List<CsvRecord> records = GetRecordsFromCsv();
                        //Get config-specified list
                        List spList = clientContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["ListName"]);
                        foreach (DataRow dataRow in dtCsv.Rows)
                        {
                            string _PersonId = String.Empty;
                            _PersonId = dataRow["person_id"].ToString();
                            if (_PersonId != String.Empty)
                            {
                                CamlQuery query = new CamlQuery();
                                query.ViewXml = String.Format("@<View><Query><Where><Eq><FieldRef Name=\"person_id\" />" +
                                    "<Value Type=\"Text\">{0}</Value></Eq></Where></Query></View>", _PersonId);
                                ListItemCollection existingMappings = spList.GetItems(query);
                                clientContext.Load(existingMappings);
                                clientContext.ExecuteQuery();

                                switch (existingMappings.Count)
                                {
                                    case 0:
                                        //No records found, needs to be added
                                        AddNewListItem(dataRow, spList, clientContext);
                                        break;
                                    default:
                                        //An existing record was found - continue with next item
                                        UpdateListItem(dataRow, spList, clientContext, existingMappings);
                                        continue;
                                }
                            }
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError("Failed: " + ex.Message);
                Trace.TraceError("Stack Trace: " + ex.StackTrace);
            }
        }

        private static void UpdateListItem(DataRow record, List spList, ClientContext clientContext, ListItemCollection items)
        {
            try
            {
                foreach (ListItem item in items)
                {
                    
                    item["person_id"] = record["person_id"].ToString();
                    item["Prefix"] = record["Prefix"].ToString();
                    item["First_Name"] = record["First_Name"].ToString();
                    item["Middle_Initial"] = record["Middle_Initial"].ToString();
                    item["Last_Name"] = record["Last_Name"].ToString();
                    item.Update();
                    
                }
                clientContext.ExecuteQuery(); 
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private static void AddNewListItem(DataRow record, List spList, ClientContext clientContext)
        {
            try
            {
                ListItemCreationInformation newItem = new ListItemCreationInformation();
                ListItem listItem = spList.AddItem(newItem);
                listItem["person_id"] = record["person_id"].ToString();
                listItem["Prefix"] = record["Prefix"].ToString();
                listItem["First_Name"] = record["First_Name"].ToString();
                listItem["Middle_Initial"] = record["Middle_Initial"].ToString();
                listItem["Last_Name"] = record["Last_Name"].ToString();
                listItem.Update();
                clientContext.ExecuteQuery();
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        private static void getCSV()
        {
            try
            {
                DataTable dt = new DataTable();
                dt = ReadCsvFile();

                foreach (DataRow dataRow in dt.Rows)
                {
                    foreach (var item in dataRow.ItemArray)
                    {
                        Console.Write(item + "\t");
                    }
                    Console.Write('\n');
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static DataTable ReadCsvFile()
        {

            string Fulltext;
            if (filePath != String.Empty)
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        Fulltext = sr.ReadToEnd().ToString(); //read full file text  
                        string[] rows = Fulltext.Split('\n'); //split full file text into rows  
                        for (int i = 0; i < rows.Count() - 1; i++)
                        {
                            string[] rowValues = rows[i].Split(';'); //split each row with comma to get individual values  
                            {
                                if (i == 0)
                                {
                                    for (int j = 0; j < rowValues.Count(); j++)
                                    {
                                        dtCsv.Columns.Add(rowValues[j]); //add headers  
                                    }
                                }
                                else
                                {
                                    DataRow dr = dtCsv.NewRow();
                                    for (int k = 0; k < rowValues.Count(); k++)
                                    {
                                        dr[k] = rowValues[k].ToString();
                                    }
                                    dtCsv.Rows.Add(dr); //add other rows  
                                }
                            }
                        }
                    }
                }
            }
            return dtCsv;
        }     


        /*private static List<CsvRecord> GetRecordsFromCsv()
                {
                    List<CsvRecord> records = new List<CsvRecord>();
                  //  using (var sr = new StreamReader(csvPath))
                    //{
                      //  var reader = new CsvReader(sr);
                        //records = reader.GetRecords<CsvRecord>().ToList();

                    const string filePath = @"D:\import.csv";
                    StreamReader streamreader = new StreamReader(filePath);
                    string[] totalData = new string[System.IO.File.ReadAllLines(filePath).Length];
                    totalData = streamreader.ReadLine().Split('|');
           
                    string strSurname = string.Empty;

                                     return records;

                */

        
        private static List<CsvRecord> GetRecordsFromCsv()
        {
            List<CsvRecord> records = new List<CsvRecord>();
            // Get the data from path.
            string sampleCSV = @"C:/Marketing20190530.csv";
            string[,] values = LoadCSV(sampleCSV);
            int num_rows = values.GetUpperBound(0) + 1;
            int num_cols = values.GetUpperBound(1) + 1;

            // Display the data to show we have it.

            for (int c = 0; c < num_cols; c++)
                Console.Write(values[0, c] + "\t");

            //Read the data.
            for (int r = 1; r < num_rows; r++)
            {
                //  dgvValues.Rows.Add();
                Console.WriteLine();
                for (int c = 0; c < num_cols; c++)
                {
                    Console.Write(values[r, c] + "\t");

                }
            }

            Console.ReadLine();
            return records;
        }

        private static string[,] LoadCSV(string filename)
        {
            // Get the file's text.
            string whole_file = System.IO.File.ReadAllText(filename);

            // Split into lines.
            whole_file = whole_file.Replace('\n', '\r');
            string[] lines = whole_file.Split(new char[] { '\r' },
                StringSplitOptions.RemoveEmptyEntries);

            // See how many rows and columns there are.
            int num_rows = lines.Length;
            int num_cols = lines[0].Split(',').Length;

            // Allocate the data array.
            string[,] values = new string[num_rows, num_cols];

            // Load the array.
            for (int r = 0; r < num_rows; r++)
            {
                string[] line_r = lines[r].Split(',');
                for (int c = 0; c < num_cols; c++)
                {
                    values[r, c] = line_r[c];
                }
            }
            // Return the values.
            return values;

        }

    }
}

